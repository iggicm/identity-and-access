<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('beautymail::templates.sunny.heading' , [
        'heading' => 'Salut ' . $application->firstname . '  ' . $application->lastname,
        'level' => 'h1',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.contentStart', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <p>
        Nous avons pris connaissance  avec votre demande.<br>
        Nous l'avons etudiee avec attention. Mais malhereusement votre profil ne correspond pas au profil que nous souhaitons pour nos membres.

    </p>

    <p>
       Pour IGGI Le responsable: <?php echo e($responsable->firstname . '  ' . $responsable->lastname); ?>

    </p>
    <?php echo $__env->make('beautymail::templates.sunny.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.button', [
           'title' => 'GAPP Accueil',
           'link' => env('HOST_WEB_CLIENT')
   ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('beautymail::templates.sunny.heading' , [
        'heading' => 'Cordialement',
        'level' => 'h4',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('beautymail::templates.sunny', ['color' => '#4204a0'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>