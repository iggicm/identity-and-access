<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('beautymail::templates.sunny.heading' , [
        'heading' => 'Invitation A reconfigurer votre mot de passe',
        'level' => 'h1',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.contentStart', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <hr>
    <p><?php echo e($user->gender == 'FEMALE'?'Mme':'M.'); ?> <strong><?php echo e($invitation->firstname . '  ' . $invitation->lastname); ?></strong>
        <br>Vous avez demande la reconfiguration de votre mot de passe.<br>
        Pour cela vous etes invite a le faire en cliquant sur le lien ci-dessous.<br>
    </p>

    <p>
        <a class="btn btn-primary btn-lg" href="<?php echo e($invitation->url); ?>">Veuillez cliquer ici pour reconfigurer votre mot de passe</a>
    </p><br>
    <p>
        vous pouvez egalement copier et coller dans la barre de recherche de votre navigateur le lien ci-dessous:<br>
        <a href="<?php echo e($invitation->url); ?>"><?php echo e($invitation->url); ?></a>
    </p>
    <p>
            Voiala
    </p>

    <?php echo $__env->make('beautymail::templates.sunny.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.button', [
        	'title' => 'IGGI Accueil',
        	'link' => env('HOST_WEB_CLIENT')
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('beautymail::templates.sunny', ['color' => '#4204a0'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>