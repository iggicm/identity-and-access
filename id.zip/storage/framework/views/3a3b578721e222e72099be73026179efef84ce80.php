<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('beautymail::templates.sunny.heading' , [
        'heading' => 'Salut ' . $application->firstname . '  ' . $application->lastname,
        'level' => 'h1',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.contentStart', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <p>
       L'application IGGI vient de recevoir votre demande d'adhesion.<br>
        Vous seriez recontacte tres bientot pour vous informer sur l'issue de votre demande.

    </p>
    <p>

    </p>

    <?php echo $__env->make('beautymail::templates.sunny.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.button', [
        	'title' => 'IGGI Accueil',
        	'link' => env('HOST_WEB_CLIENT')
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('beautymail::templates.sunny', ['color' => '#4204a0'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>